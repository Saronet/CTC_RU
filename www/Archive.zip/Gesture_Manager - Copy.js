 gestureMan =  function(){

     this.showPage = function()
     {
         NavigationMan_.navigate(NavigationMan_.pagePosition,"gesture");

        
     }
    

}