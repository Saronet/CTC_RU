function RecipeMan () {
    this.whatUNeedList = new Array();

    this.showRecipePage = function(recipe) {
        this.clearRecipePage();
        NavigationMan_.navigate("categories", "recipe");

        var id = $(recipe).data("id");
        var category = $(recipe).data("category");
        var result = this.checkIfRecipeExist(id, category);
        if(result == false)
        { this.getPostContent(id, category); }
        else {
            this.setRecipeContent(result);

        }
        
        //set favorite in cookie
        $("#addFavoiteRecipe").click(function() {

            //sent the clicked obj with the recipe data
            favoriteMan_.addRecipeToList(this);
            $(this).parent().fadeOut();
           
        });

    }
   
    this.checkIfRecipeExist = function(id, category) {
        var list = (recipesArray)[category];
        var exist = false;
        list = $(list).attr("list");
        var indexInList = -1;
        $.each(list, function(index, record) {
            if(index == id) {
                indexInList = id;
                $.each(record, function(index2, sub_record) {
                    //console.log( index2, sub_record );
                    if(index2 == "custom_fields") {

                        if($(this).attr("wpcf-instructions") != undefined)
                        { exist = true; }

                    }
                });
            }
        });
        if(exist == true) {
            exist = list[indexInList];
        }
        return exist;

    }

    this.getPostContent = function(id) {
        showLoading();
        setTimeout("jsonMan_.get_post_by_id('"+ id+"', 'recipeMan_.getPostContentCB')", 100);

    }

    this.getPostContentCB = function(val) {
        
        jsonToArrayOneRecipe($(val)[0].post);
        var eventObj = val.post;
        recipeMan_.setRecipeContent(eventObj);
        hideLoading();
        
    }

    this.setRecipeContent = function(currentRecipe) {

        recipeMan_.whatUNeedList = [];
        var currentRecipeDetails = $(currentRecipe).attr("custom_fields");
        var currentRecipeData = $(currentRecipe);

        //set what to do tab
        $("#recipePage_what_to_do_title").text(currentRecipeDetails["wpcf-recipe_name"][0]);
        $("#recipePage_what_to_do_text").html(currentRecipeDetails["wpcf-instructions"][0]);

        //set what u need tab
        //var ingraCollect = currentRecipeDetails["wpcf-ingradient"]; //["wpcf-formatted_ingradients"]
        var ingraCollect = currentRecipeDetails["wpcf-formatted_ingradients"][0].split(",");

        $(ingraCollect).each(function(i) {
            /*var singleLine = this.split(";");
            if(singleLine[1] == undefined) {
            singleLine[1] = "";
            }*/
            if(this != "") {
                $("#one_recipe_what_u_need_list").append(" <li>" +
                                            "<div class=\"food_name_what_u_need_list_div\"><span class=\"food_name_what_u_need_list\">" + this + "</span></div>" +
                //"<span class=\"amount_need\">" + singleLine[1] + "</span>" +
                                            "</li>");
                recipeMan_.whatUNeedList[i] = this;// singleLine[0] + " " + singleLine[1];
            }

        });

        //set description tab
        //$("#totalTimeRecipePage").text(currentRecipeDetails["wpcf-total_time"][0] + " мин.");
        $("#totalTimeRecipePage").text(currentRecipeDetails["wpcf-total_time"][0] + " Min."); //for english
        $("#levelRecipPage").text(currentRecipeDetails["wpcf-complexity_level"][0]);

        var small_imag = currentRecipeDetails["wpcf-image"][0];
        if(small_imag == "") { small_imag = "images/default_pic.jpg"; }

        $("#imgRecipePage").attr("src", small_imag);
        $("#titleRecipePage").text(currentRecipeDetails["wpcf-recipe_name"][0]);
        $("#descRecipePage").text(currentRecipeDetails["wpcf-short_describtion"][0]);

        $("#addFavoiteRecipe").data("recipeObj", currentRecipeData[0]);

        if(favoriteMan_.isInFavorite(currentRecipeData[0].id)) {
            $("#addFavoiteRecipe").parent().hide();
        }
        else {
            $("#addFavoiteRecipe").parent().show();
        }

        if(isIpad()) {
            checkHtml($(".one_recipe_text_pic"), 250);
        }
        else {
            checkHtml($(".one_recipe_text_pic"), 88);
        }

        //}

    }

    this.addToShoppingList = function() {

        shoppingMan_.addFromRecipePage(this.whatUNeedList);
    }

    this.clearRecipePage = function()
    {
        //clear the fields of recipe page
        
         //set what to do tab
        $("#recipePage_what_to_do_title").text("");
        $("#recipePage_what_to_do_text").html("");

        //set what u need tab
        $("#one_recipe_what_u_need_list").html("");
 
        //set description tab
        $("#totalTimeRecipePage").text("");
        $("#levelRecipPage").text("");
        $("#imgRecipePage").attr("src", "");
        $("#titleRecipePage").text("");
        $("#descRecipePage").text("");
    }
    this.description_recipe = function()
    {
        $('.recipes_background_main').show();
        $('.recipes_background_what_u_need').hide();
        $('.recipes_background_what_to_do').hide();
        $('.Gesture_btn').css({"background-position":"0px"})

    }

    this.what_u_need = function() {
        $('.recipes_background_main').hide();
        $('.recipes_background_what_u_need').show();
        $('.recipes_background_what_to_do').hide();
        if(isIpad()) {
            $('.Gesture_btn').css({ "background-position": "-101px 50%" })
        }
        else {
            $('.Gesture_btn').css({ "background-position": "-58px 50%" }); //iphone
        }
    }


    this.what_to_do = function()
    {
      $('.recipes_background_main').hide();
        $('.recipes_background_what_u_need').hide();
        $('.recipes_background_what_to_do').show();
        if(isIpad()) {
            $('.Gesture_btn').css({ "background-position": "-101px 50%" })
        }
        else {
            $('.Gesture_btn').css({ "background-position": "-58px 50%" }); //iphone
        }
    }


    }

    
     