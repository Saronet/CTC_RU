//var FeatureMan_;
function MainMan () {
    this.initFeatures = function() {
        featureMan_ = new FeatureMan();
        var list = featureMan_.createList();
        
        
    }

    this.initSearch = function() {
        searchMan_ = new searchMan();
        searchMan_.start();
        //searchMan_.attachEvents();
    }

    this.initIcons = function(){
      
        

    }
    this.gotoMain = function()
    {
        NavigationMan_.navigate(NavigationMan_.pagePosition,"main");
    }
}