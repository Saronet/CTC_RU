termSingle_Manager = function(term) {

    this.showPage = function(term) {
        $("#termImg").attr("src", "");
        NavigationMan_.navigate(NavigationMan_.pagePosition, "termSingle");

        var details = $(term).data("details");
        $(".second_nav_text").text($(details).attr("wpcf-term_name")[0]);
        $("#one_recipe_text_pic_term").text($(details).attr("wpcf-term_name")[0]);
        $("#one_recipe_text_discription_term").text($(details).attr("wpcf-describtion")[0]);
        $("#termImg").attr("src", $(details).attr("wpcf-image")[0]);


    }

}
