function recipeArrayObj ()
{
    this.category;
    this.categoryTitle;
    this.page = 1;
    this.list = new Object;

}